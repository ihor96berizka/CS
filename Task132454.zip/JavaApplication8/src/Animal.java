
import java.util.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * here is class used to represent animal instances
 */
public class Animal {
    Animal(String Speci,String name, Date dt){
   
    Species = Speci;
    Name = name;
    Date_Of_Registration = dt;
    }
  
   private String Species;
   private String Name;
   private Date Date_Of_Registration;
    public String toString()
    {
    return this.Species+" "+this.Name+" "+this.Date_Of_Registration;
    }
}
