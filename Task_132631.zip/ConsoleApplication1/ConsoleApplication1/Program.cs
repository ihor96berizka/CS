﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Decimal loanAmount, annualInterest, number_of_months, down_payment;
            Decimal Payment, Portion_of_payment_to_repay, Portion_of_payment_to_reduce;
            Boolean exit = false;
            Char ext;
            Decimal total = 0;
            while (!exit)
            {
                Console.Write("Loan Amount:  = ");
                loanAmount = Convert.ToDecimal(Console.ReadLine());
                Console.Write("Annual interest rate (ARP):  = ");
                annualInterest = Convert.ToDecimal(Console.ReadLine());
                annualInterest /= 100;
                Console.Write("Number of months : = ");
                number_of_months = Convert.ToDecimal(Console.ReadLine());
                Console.Write("Down payment: = ");
                down_payment = Convert.ToDecimal(Console.ReadLine());
                Decimal temp;// = loanAmount - down_payment;
                temp = loanAmount - down_payment;
                Decimal years = number_of_months / 12;
                Portion_of_payment_to_reduce = temp * annualInterest / (12);
                Portion_of_payment_to_repay = temp / number_of_months;
                total += loanAmount;
                for (Decimal month = 1; month <= number_of_months; month++)
                {
                    Portion_of_payment_to_reduce = temp * annualInterest / (12);
                    Payment = Portion_of_payment_to_repay + Portion_of_payment_to_reduce;
                    Console.WriteLine("Month number = {0},  Payment = {1}, Portion of payment used to repay interest = {2}, Portion of payment used to redused principal = {3}",
                        month, Round(Payment), Round(Portion_of_payment_to_repay), Round(Portion_of_payment_to_reduce));
                    // loanAmount -= Portion_of_payment_to_reduce;
                    temp -= Portion_of_payment_to_repay;
                    total += Portion_of_payment_to_reduce;
                }
                Console.WriteLine("Total: " + Round(total) + "\n");
                Console.Write("Exit?(y/n)   ");
                ext = Convert.ToChar(Console.ReadLine());
                if (ext.Equals('y')) exit = true;
            }


        }
        static Decimal Round(Decimal number)
        {
            return Math.Round(number, 2);
        }
    }
}
