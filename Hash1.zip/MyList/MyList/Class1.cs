﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyList
{
    class MyList
    {
        public class Node
        {
            public String data;
            public Node next, previous;
            public Int32 index;
        }
        Node first, last;
        public MyList()
        {
            first = null;
            last = null;
        }
        Boolean isEmpty()
        {
            if (first == null && last == null)
                return true;
            else
                return false;
        }
        public void add_begin(String item)//+
        {
            Node temp = new Node();
            temp.data = item;
            temp.next = first;
            temp.previous = null;
            if (!isEmpty())
            {
                first.previous = temp;
            }
            if (isEmpty())
            {
                last = temp;
            }
            first = temp;
        }
        public void add_end(String item)
        {
            Node temp = new Node();
            temp.data = item;
            temp.next = null;
            temp.previous = last;
            if (!isEmpty())
            {
                last.next = temp;
            }
            if (isEmpty())
            {
                first = temp;
            }
            last = temp;
        }
        public void del_begin()
        {
            if (isEmpty())
            {
                Console.WriteLine("Empty!");
                last = null;
                return;
            }

            if (!isEmpty())
            {
                first.previous = null;
            }

            /*  if (isEmpty())
              {
                  last = null;
              }*/
            Node temp = first;
            first = temp.next;


        }
        public void del_end()
        {
            if (isEmpty())
            {
                Console.WriteLine("Empty!");
                first = null;
                return;
            }
            Node temp = last;
            last = temp.previous;
            if (!isEmpty())
            {
                last.next = null;
            }
        }
        public Node search(Int32 index)//шукає по заданому value
        {

            Node temp = first;
            while (temp != null)
            {
                if (temp.data.Equals(index))
                {
                    return temp;
                }
                else temp = temp.next;
            }
            return null;
        }
        public void add_mid(Int32 index, String DATA)//+
        {
            //Node pKey = search(item);
            if (search(index) == null) return;
            if (search(index) == last)
            {
                add_end(DATA);
            }
            if (search(index) == first)
            {
                add_begin(DATA);
            }
            if (search(index) != last && search(index) != first && search(index) != null)
            {
                Node pKey = search(index);
                Node temp = new Node();
                temp.data = DATA;
                temp.next = pKey.next;
                temp.previous = pKey;
                pKey.next = temp;
                temp.next.previous = temp;//?                
            }
        }
        public void Del_Mid(Int32 item)//видалає по заданому value
        {
            Node pKey = search(item);
            if (pKey == null) { Console.WriteLine("key not found!"); return; }
            if (pKey == last) del_end();
            if (pKey == first) del_begin();
            if (pKey != first && pKey != last && pKey != null)
            {
                pKey.previous.next = pKey.next;
                pKey.next.previous = pKey.previous;
            }
        }
        public void show()
        {
            if (first == null)
            {
                Console.WriteLine("Empty");
                return;
            }
            Int32 i = 0;
            Node temp;
            temp = first;
            while (temp != null)
            {
                i++;
                temp.index = i;
                Console.Write(temp.data + " ");
                temp = temp.next;
            }
            Console.WriteLine();
        }
    }
}
