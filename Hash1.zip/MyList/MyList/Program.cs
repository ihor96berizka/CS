﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyList
{
    class Program
    {
        const int m = 11;
        private static string choice;

        static void Main(string[] args)
        {
            // MyList[] list = new MyList[m];
            List<int>[] secList = new List<int>[m];
            for (int i = 0; i < m; i++)
            {
                // list[i] = new MyList();
                secList[i] = new List<int>();
            }
            Boolean exit = true;
            int item;
            do
            {
                Console.WriteLine("Select action:");
                Console.WriteLine("1 - add_key ");
                Console.WriteLine("2 - search_key ");
                Console.WriteLine("3 - delete_key ");
                Console.WriteLine("4 - show table ");
                Console.WriteLine("5 - Exit ");
                Console.Write("Your choise is: ");
                choice = Console.ReadLine();
                if (choice.Equals("1"))
                {
                    Console.Write("Enter key: ");
                    item = Convert.ToInt32(Console.ReadLine());
                    int hk = h(item, m);
                    //list[hk].add_end(item.ToString());
                    secList[hk].Add(item);
                }
                if (choice.Equals("2"))
                {
                    Console.Write("Enter key: ");
                    item = Convert.ToInt32(Console.ReadLine());
                    int hk = h(item, m);
                    //list[hk].add_end(item.ToString());
                    /* var data = list[hk].search(item);*/
                    var data = secList[hk].Where(g => g == item).ToList<int>();
                    if (data.Count!=0) Console.WriteLine("Found key: " + data[0]);
                    else Console.WriteLine("Key not found!");
                }
                if (choice.Equals("3"))
                {
                    Console.Write("Enter key: ");
                    item = Convert.ToInt32(Console.ReadLine());
                    int hk = h(item, m);
                    secList[hk].Remove(item);
                    //list[hk].Del_Mid(item);
                }
                if (choice.Equals("4"))
                {
                    foreach (var node in secList)
                    {
                        if (node.Count == 0) { Console.WriteLine("Empty list "); continue; }
                        foreach (var ke in node)
                        {
                            Console.Write(ke + " ");
                        }
                        Console.WriteLine();
                    }
                }
                if (choice.Equals("5"))
                {
                    exit = false;
                }
            } while (exit);
            Console.Read();
            // NewMethod();

        }

        private static void NewMethod()
        {
            String choice = null;
            Int32 item;
            /*  Boolean exit = true;
              do
              {
                  Console.WriteLine("Select action:");
                  Console.WriteLine("1 - add_Begin ");
                  Console.WriteLine("2 - add_End ");
                  Console.WriteLine("3 - del_Begin ");
                  Console.WriteLine("4 - del_End");
                  Console.WriteLine("5 - Searh ");
                  Console.WriteLine("6 - add_Mid ");
                  Console.WriteLine("7 - del_Mid");
                  Console.WriteLine("8 - Show List ");
                  Console.WriteLine("9 - Exit ");
                  Console.Write("Your choise is: ");
                  choice = Console.ReadLine();
                  if (choice.Equals("1"))
                  {
                      Console.Write("Enter your element :");
                      item = Convert.ToInt32(Console.ReadLine());
                      list.add_begin(item.ToString());
                  }
                  if (choice.Equals("2"))
                  {
                      Console.Write("Enter your element :");
                      item = Convert.ToInt32(Console.ReadLine());
                      list.add_end(item.ToString());
                  }
                  if (choice.Equals("3"))
                  {
                      list.del_begin();    
                  }
                  if (choice.Equals("4"))
                  {
                      list.del_end();
                  }
                  if (choice.Equals("5"))
                  {
                      Int32 Item;
                      Console.Write("What you want to find?");
                      Item = Convert.ToInt32(Console.ReadLine());
                      MyList.Node temp;
                      temp = list.search(Item);
                      Console.WriteLine("Here is your element: "+temp.data);
                  }
                  if (choice.Equals("6"))
                  {
                      Console.Write("Enter value ");
                      String data = Console.ReadLine();
                      Console.Write("Index -");
                      item = Convert.ToInt32(Console.ReadLine());
                      list.add_mid(item,data);
                  }
                  if (choice.Equals("7"))
                  {
                      Console.Write("enter index :");
                      item = Convert.ToInt32(Console.ReadLine());
                      list.Del_Mid(item);
                  }
                  if (choice.Equals("8"))
                  {
                      Console.WriteLine("Elements in list:");
                      list.show();
                      Console.WriteLine();
                  }
                  if (choice.Equals("9")) 
                  {
                      exit = false;
                  }
              } while (exit);
             */
        }

        static Int32 h(int k, int m)
        {
            return k % m;
        }
    }
}
