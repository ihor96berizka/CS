#include <QCoreApplication>
#include<iostream>
#include<string>
using namespace std;

void Floyd();
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
   Floyd();
    return a.exec();
}
void Floyd()
{
   const int  n = 4;
    int**w=new int*[n];
    for(int i = 0; i < n; i++) *(w+i) = new int[n];
    int**teta = new int*[n];
    for(int i = 0; i < n; i++) *(teta+i) = new int[n];
    int inf = 100;
   w[0][0] = 0;      w[0][1] = -2;    w[0][2] = 3;   w[0][3] = -3;
   w[1][0] = inf;    w[1][1] =  0;    w[1][2] = 2;   w[1][3] = inf;
   w[2][0] = inf;    w[2][1] = inf;   w[2][2] = 0;   w[2][3] = -3;
   w[3][0] = 4;      w[3][1] =  5;    w[3][2] = 5;   w[3][3] = 0;
    for(int i = 0;i < n; i++)
    for(int j = 0;j < n; j++)
    {
        if(i != j) teta[i][j] = i;
        else teta[i][j] = 0;
    }
     for(int k = 0; k < n; ++k)
        {
         for(int i = 0; i < n; ++i)
            {
            for(int j = 0; j < n; j++)
               {
                 if(*(*(w+i)+k)+*(*(w+k)+j) < *(*(w+i)+j))
                 {
                     w[i][j] = w[i][k] + w[k][j];
                   if(i != j)  teta[i][j] = teta[k][j];
                 }
               }
             }
         cout<<"Iteration # "<<k<<endl;
         cout<<"W : "<<endl;
         for(int i = 0; i < n; i++)
         for(int j = 0; j < n; j++)
         {
          cout<<w[i][j]<<" ";
          if(j == n-1)cout<<endl;
         }
         cout<<"Teta : "<<endl;
         for(int i = 0; i < n; i++)
         for(int j = 0;j < n; j++)
         {
         if(i!=j) cout<<(teta[i][j]+1)<<" ";
         else cout<<teta[i][j]<<" ";
          if(j == n-1)cout<<endl;
         }

      }
int b,d;
string s = "";
cout<<" u = ";
cin>>b;
cout<<" v = ";
cin>>d;
--d;
--b;
if (b == d)
{
s.append(std::to_string(b) + ";");
}
else
{
int* f = new int[6];
f[0] = d + 1;

for (int i = 0; i < 3; i++)
{
if (teta[b][d] == b)
{
d = teta[b][d] + 1;
f[i + 1] = d;
break;
}
else
{
d = teta[b][ d] + 1;

f[i + 1] = d;
--d;
}

}
for (int i = 3; i >= 0; i--)
  {
if (f[i] == 0)
{
    continue;
}
   s.append(std::to_string(f[i]) + ";");
  }
}
cout<<"Path : "<<s<<endl;
cout<<"\ndone";
    for(int i = 0; i < n; i++) delete *(teta+i);
    delete teta;
    for(int i = 0; i < n; i++) delete *(w+i);
    delete w;
}
