﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hash2
{
    class Program
    {
        static Int32 m = 11;
        static Int32[] hash = new Int32[m];// hash table
        static Int32 c1 = 1, c2 = 3;
        static Int32 m_ = m - 1;
        static Int16 num_of_keys = 0;
        static void Main(string[] args)
        {
            for (int i = 0; i < hash.Length; i++)
            {
                hash[i] = -1;
            }//-1 = means that item in hash is empty
          Console.WriteLine("\tMenu\n");
            int to_do;
            int func;
            Console.WriteLine("1 - Insert\n");
            Console.WriteLine("2 - Search\n");
            Console.WriteLine("3 - Delete\n");
            Console.WriteLine("4 - show\n");
            Console.WriteLine("5 - exit\n");
            Console.Write("Choise: ");
            to_do = Convert.ToInt32(Console.ReadLine());
            while (true)
            {
                Console.WriteLine("Select func \n");
                Console.WriteLine("1 - linear \n");
                Console.WriteLine("2 - quadratic \n");
                Console.WriteLine("3 - double \n");
                Console.Write("choise  :");
                func = Convert.ToInt32(Console.ReadLine());
                Func<int, int, int> f = new Func<int, int, int>(h_linear);
                if (func == 1) f = new Func<int, int, int>(h_linear);
                if (func == 2) f = new Func<int, int, int>(h_quad);
                if (func == 3) f = new Func<int, int, int>(h_double);
                if (to_do == 1)
                {
                    if (num_of_keys < m)
                    {
                        int key;
                        Console.Write("enter key = :");
                        key = Convert.ToInt32(Console.ReadLine());
                        HashInsert(key, f);
                        num_of_keys++;
                    }
                    else Console.WriteLine("Hash is full\n");
                }
                if (to_do == 2)
                {
                    int key;
                    Console.WriteLine("enter key to search: ");
                    key = Convert.ToInt32(Console.ReadLine());
                    int res = HashSearch(key);
                    Console.WriteLine("Key = " + key + " index = " + res);
                }
                if (to_do == 3)
                {
                    if (num_of_keys > 0)
                    {
                        int key;
                        Console.Write("enter key = :");
                        key = Convert.ToInt32(Console.ReadLine());
                        HashDelete(key);
                        num_of_keys--;
                    }
                    else Console.WriteLine("Has is empty!\n");
                }
                if (to_do == 4)
                {
                    Console.WriteLine("Table: \n");
                    foreach (var item in hash)
                    {
                        Console.WriteLine("item = " + item);
                    }
                }
                if (to_do == 5)
                {
                    break;
                }
                Console.WriteLine("\tMenu\n");
                Console.WriteLine("1 - Insert\n");
                Console.WriteLine("2 - Search\n");
                Console.WriteLine("3 - Delete\n");
                Console.WriteLine("4 - show\n");
                Console.WriteLine("5 - exit\n");
                Console.Write("Choise: ");
                to_do = Convert.ToInt32(Console.ReadLine());
            }
            /*HashInsert(10,h_quad);
            HashInsert(22, h_quad);
            HashInsert(31, h_quad);
            HashInsert(4, h_quad);
            HashInsert(15, h_quad);
            HashInsert(28, h_quad);
            HashInsert(17, h_quad);
            HashInsert(88, h_quad);
            HashInsert(59, h_quad);
            Console.WriteLine("Table\n");
            foreach (var item in hash)
            {
                Console.WriteLine("item = " + item);
            }
            int index = HashSearch(22);
            Console.WriteLine("index = "+index+" key = "+22);*/
            Console.Read();
        }
        static Int32 h(Int32 k)//different hash functions
        {
            return k % m;
        }
        static Int32 h_linear(Int32 k, Int32 i)
        {
            return (h(k) + i) % m;
        }
        static Int32 h_quad(Int32 k, Int32 i)
        {
            return ((h(k) + c1 * i + c2 * i * i) % m);
        }
        static Int32 h2(Int32 k) { return 1 + (k % (m - 1)); }
        static Int32 h_double(Int32 k, Int32 i)
        {
            return (h(k) + i * h2(k)) % m;
        }
        static Int32 HashSearch(Int32 k)
        {
            Int32 i = 0;
            int j = 0;
            do
            {
                j = h_linear(k, i);
                if (hash[j] == k) return j;
                else i++;
            } while (hash[j] != -1 && i != m);
            return -1;
        }
        static Int32 HashInsert(Int32 k, Func<int, int, int> h)
        {
            Int32 i = 0;
            do
            {
                int j = h(k, i);
                {
                    if (hash[j] == -1)
                    {
                        hash[j] = k;
                     //   Console.WriteLine("index = :" + j + " Value: " + k);
                        return j;
                    }
                    else i++;
                }
            } while (i != m);
          //  Console.WriteLine("index = : " + -1);
            return -1;
        }
        static void HashDelete(int k)
        {
            int j = HashSearch(k);
            hash[j] = -1;
        }
    }
}
