﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Xml.Serialization;
using System.IO;

namespace Task_130275
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

    public   static List<Bike> list_Of__Bikes = new List<Bike>();// static list of bikes
           /* {
            new Bike{ Make = "Honda", Model = "CBR", Size="600c", Cost=5000, Year=2008},
            new Bike{ Make = "Yamaha", Model = "YBR", Size="600c", Cost=5000, Year=2008}
            };*/
        private void Form1_Load(object sender, EventArgs e)//form load event 
        {
           
            XmlSerializer xmlSerialaizer = new XmlSerializer(typeof(List<Bike>)); // works with xml files

            List<Bike> readBikes = new List<Bike>();//list of bikes from file
            FileStream fr = new FileStream("bikes.xml", FileMode.Open);// filestream - to read data from file
            readBikes = (List<Bike>)xmlSerialaizer.Deserialize(fr);//reading from file
            list_Of__Bikes = readBikes;
            var orderedList = list_Of__Bikes.OrderBy(g => g.Model);//sorting list alphabetically by Model(LINQ to objects)
            listBox1.DataSource = orderedList.ToList<Bike>();//add items to listbox
            listBox1.Refresh();// update listbox
            fr.Close();//close file descriptor
        }

        private void buttonSave_Click(object sender, EventArgs e)// save List to file
        {
            XmlSerializer xmlSerialaizer = new XmlSerializer(typeof(List<Bike>));// works with xml files

            FileStream fw = new FileStream("bikes.xml", FileMode.OpenOrCreate);
            xmlSerialaizer.Serialize(fw, list_Of__Bikes);//write list into file
            fw.Close();
            listBox1.Refresh();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)//show details about selected item in listbox
        {
            String []display = listBox1.SelectedItem.ToString().Split(' ');// array of strings to represent Make, Model and Size
            var bike = list_Of__Bikes.Where(g =>  g.Model == display[1] && g.Make == display[0] && g.Size == display[2]).Select(g => g);//seach in list selected item
            foreach (var item in bike)// show details about selected item in textboxes
            {
                textMake.Text = item.Make;
                textCost.Text = item.Cost.ToString();
                textModel.Text = item.Model;
                textYear.Text = item.Year.ToString();
                textSize.Text = item.Size;
            }
            listBox1.Refresh();
        }

        private void buttonAdd_Click(object sender, EventArgs e)//add new item to the list
        {
            Bike newItem = new Bike();//create new instance of Bike structure
            newItem.Model = textModel.Text;//
            newItem.Make = textMake.Text;//
            newItem.Size = textSize.Text;//                   adding data to the instance
            newItem.Year = Convert.ToInt32(textYear.Text);//
            newItem.Cost = Convert.ToInt32(textCost.Text);//
            list_Of__Bikes.Add(newItem);//add new bike to the list
            var sorted = list_Of__Bikes.OrderBy(g => g.Model);//sort list
            listBox1.DataSource = sorted.ToList<Bike>();//show new list in listbox
            listBox1.Refresh();
        }

        private void buttonUpdate_Click(object sender, EventArgs e)//update selected item
        {
            String[] display = listBox1.SelectedItem.ToString().Split(' '); // array of strings to represent Make, Model and Size
            var bike = list_Of__Bikes.Where(g => g.Model == display[1] && g.Make == display[0] && g.Size == display[2]).Select(g => g);//find selected item in list
            List<Bike> update = bike.ToList<Bike>();
            Bike item = new Bike 
            {
                Cost = Convert.ToInt32(textCost.Text),
                Size = textSize.Text,
                Year = Int32.Parse(textYear.Text),
                Make = textMake.Text,
                Model = textModel.Text
            };//updating info about selected item
            list_Of__Bikes.Remove(update.ElementAt(0));//remove old item
            list_Of__Bikes.Add(item);//add updated item
            var sorted = list_Of__Bikes.OrderBy(g => g.Model);//sorting
            listBox1.DataSource = sorted.ToList<Bike>();//show new list in listbox
            listBox1.Refresh();
        }

        private void buttonDelete_Click(object sender, EventArgs e)//delete selected item
        {
            String[] display = listBox1.SelectedItem.ToString().Split(' ');// array of strings to represent Make, Model and Size
            var bike = list_Of__Bikes.
                Where(g => g.Model.Equals(display[1]) && g.Make.Equals(display[0]) && g.Size.Equals(display[2])).
                Select(g => g);//find selected item in list

            List<Bike> update = bike.ToList<Bike>();
            list_Of__Bikes.Remove(update.ElementAt(0));//remove selected item
            var sorted = list_Of__Bikes.OrderBy(g => g.Model);//sorting list by model
            listBox1.DataSource = sorted.ToList<Bike>();//show new list in listbox
            listBox1.Refresh();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)//fomr closing event. same as button_save
        {
            XmlSerializer xmlSerialaizer = new XmlSerializer(typeof(List<Bike>));

            FileStream fw = new FileStream("bikes.xml", FileMode.Create);
            xmlSerialaizer.Serialize(fw, list_Of__Bikes);
            fw.Close();
            listBox1.Refresh();
        }
    }
}
