﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_130275
{
    //struct to represent info about bikes
  public  struct Bike
    {
        public String Make { get; set; }
        public String  Model { get; set; }
        public String Size { get; set; }
        public Int32 Year { get; set; }
        public Int32 Cost { get; set; }
        public override string ToString()//override ToString(); method. is used for displaying items in listbox
        {
            return Make + " " + Model + " " + Size + " ";
        }
    }
}
