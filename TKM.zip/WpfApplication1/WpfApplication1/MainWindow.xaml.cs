﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Click(object sender, RoutedEventArgs e)
        {
            double[] x = { 5, 7, 17,19,21,25,55 };
            double[] p = { 0.01, 0.05, 0.3, 0.3, 0.3,0.02,0.02 };
            double[] interv = new double[p.Length];
            int n = Convert.ToInt32(txt_N.Text);
            double[] ri = new double[n];
            
            for (int i = 0; i < p.Length; i++)
            {
                interv[i] = p.Take(i + 1).Sum();
            }
            ri = Class1.GenRi(n);
            double[] key = new double[p.Length];
            Class1.Count(ri, interv, ref key);
            double[] X = new double[n];
            List<Point> lis = GetPoints(x,key);
            double[] y2 = new double[p.Length];
            for (int i = 0; i < p.Length; i++)
            {
                y2[i] = p[i] * n;
            }
            List<Point> lis2 = GetPoints(x, y2);
            gist.ItemsSource = lis;
            gist2.ItemsSource = lis2;
        }

        private static List<Point> GetPoints(double[]x,double []y)
        {
            List<Point> lis = new List<Point>();
            Point[] mas = new Point[x.Length];
            for (int i = 0; i < x.Length; i++)
            {
                mas[i] = new Point();
                mas[i].X = x[i];
                mas[i].Y = y[i];
                lis.Add(mas[i]);
            }
            return lis;
        }
    }
}
