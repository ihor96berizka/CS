﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Lab_1
{
    public partial class Form1 : Form
    {
        static List<double[]> graph = new List<double[]>();
        static Form2 f;
        public Form1()
        {
            InitializeComponent();
            this.dataGridView1.ColumnCount = 2;
            this.dataGridView1.RowCount = 2;
            this.dataGridView2.RowCount = 1;
            this.dataGridView2.ColumnCount = 1;
        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            this.dataGridView1.RowCount = Convert.ToInt32(textBox2.Text)+1;
            this.dataGridView2.RowCount = Convert.ToInt32(textBox1.Text);
            Int64 a = 0, m = 0, n = 0;
            List<Double> res = new List<double>();
            Int32 k =  Convert.ToInt32(textBox1.Text);// == RowCount
            Int64 X_0;
            double h = 0, bl = 1;
            Int64 L = Convert.ToInt32(textBox2.Text);//кількість підінтервалів
            h = bl / L;
            Double[] inter = new Double[L];
            inter[0] = 0;
            for (int i = 1; i < inter.Length; i++)
            {
                inter[i] += inter[i - 1] + h;
            }

            //Console.WriteLine();
            m = Class1.getSeed();
            a = 1234569;
            X_0 = Class1.getSeed();
            n = Class1.getSeed();
            this.Text = X_0.ToString();                                // k = 20;
            for (int i = 0; i < k; i++)
            {
                X_0 = (a * X_0) % m;
                res.Add(Math.Abs((double)(X_0) / n));
              //  Console.WriteLine(res[i]);
            }
            double[] mas = new double[L];
            Class1.Count(res.ToArray(), inter, ref mas);
            //Console.WriteLine("mas");
            double[] arr = res.ToArray();
             for (int i = 0; i < mas.Length; i++)
             {
                 // Console.WriteLine(mas[i] + "   " + inter[i]);
                dataGridView1[0,i].Value = mas[i].ToString();
                dataGridView1[1,i].Value = inter[i].ToString();
             }
            for (int i = 0; i <arr.Length; i++)
            {
                dataGridView2[0, i].Value = arr[i].ToString();
            }
          //  this.Text = "mas.len = " + mas.Length + "  Inter.len = " + inter.Length;
            graph.Add(mas);
            graph.Add(inter);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            f = new Form2(graph);
            f.Show();
        }
    }
}
