﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Windows_Lab_1
{
  static  class Class1
    {
        public static void Count(Double[] a, Double[] inter, ref double[] key)//рахує  кількість одинакових елементів послідовності
        {
            for (int i = 0; i < a.Length; i++)
            {
                for (int j = 0; j < inter.Length-1; j++)
                {
                    if (j == 0)
                    {
                        if (a[i] > inter[j] && a[i] < inter[j+1])
                        {
                            key[j]++;
                        }
                    }
                    else
                    {
                        if (a[i] > inter[j] && a[i] < inter[j+1])
                        {
                            key[j]++;
                        }
                    }
                }          
            }
            //return ret;
        }
        public static double M_X(Dictionary<Double, Double> input, Int64 n) //математичне спдівання M(X)
        {
            double[] value = input.Select(g => g.Value).ToArray();
            double[] key = input.Select(g => g.Key).ToArray();
            double m_x = 0;
            for (int i = 0; i < value.Length; i++)
            {
                m_x += value[i] * (key[i] / (double)n);
            }
            return m_x;
        }
        public static double M_X_2(Dictionary<Double, Double> input, Int64 n)// M(X^2)
        {
            double[] value = input.Select(g => g.Value).ToArray();
            double[] key = input.Select(g => g.Key).ToArray();
            double m_x = 0;
            for (int i = 0; i < value.Length; i++)
            {
                m_x += value[i] * value[i] * (key[i] / (double)n);
            }
            return m_x;
        }
        public static double D_X(Dictionary<double, double> inp, Int64 n) //D(X)
        {
            return M_X_2(inp, n) - Math.Pow(M_X(inp, n), 2);
        }
        public static Int64 getSeed()
        {
            return Math.Abs((Int64)(DateTime.Now.ToBinary()))/100;
        }
    }
}
