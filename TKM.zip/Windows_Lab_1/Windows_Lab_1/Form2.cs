﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Lab_1
{
    public partial class Form2 : Form
    {
        static List<double[]> draw = new List<double[]>();
        public Form2(List<double[]>li)
        {
            InitializeComponent();
            draw = li;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            double[] x = draw[1];
            double[] y = draw[0];
            for (int i = 0; i < x.Length; i++)
            {
                chart1.Series[0].Points.AddXY(x[i], y[i]);
            }
        }
    }
}
