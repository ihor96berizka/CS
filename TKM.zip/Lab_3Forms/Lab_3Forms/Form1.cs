﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_3Forms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.chart1.Series[0].Points.Clear();
            this.chart1.Series[1].Points.Clear();
            double a = 0, b = 4;
            double M = 0.5;
            int k = Convert.ToInt32(textBox1.Text);
            double X_0;
            double eta;
            List<double> X = new List<double>();
            List<double> Y = new List<double>();
            double r1, r2;
            Random rand = new Random();
            for (int i = 0; i < k; i++)
            {
                r1 = rand.NextDouble();
                r2 = rand.NextDouble();
                X_0 = a + r1 * (b - a);
                eta = r2 * M;
                if (eta < f(X_0))
                {
                    X.Add(X_0);
                    Y.Add(eta);
                }
            }
            double[] x = new double[250];
            double[] y = new double[250];
            tab(ref x, ref y);
            for (int i = 0; i < x.Length; i++)
            {
                chart1.Series[0].Points.AddXY(x[i], y[i]);
            }
            for (int i = 0; i < X.Count; i++)
            {
                chart1.Series[1].Points.AddXY(X[i], Y[i]);
            }
        }
        static double f(double x)
        {
            if (x >= 0 && x <= 2) return 0.25;
            if (x > 2 && x <= 4) return 1 - x/4;
            return 0;
        }
        static void tab(ref double[] x,ref double[]y)
        {
            x[0] = 0;
            x[x.Length - 1] = 4;
            double h = (x[x.Length - 1] - x[0]) / 250;
            y[0] = f(x[0]);
            for (int i = 1; i < x.Length; i++)
            {
                x[i] = h + x[i - 1];
                y[i] = f(x[i]);
            }
        }
    }
}
