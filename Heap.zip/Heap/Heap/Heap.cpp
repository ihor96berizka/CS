// Heap.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>
#include"Header.h"
int main()
{
	using std::cout;
	using std::endl;

	int*A = new int[N+1]{0,4,1,3,2,16,9,10,14,8,7};
	/*for (size_t i = 1; i <=N; i++)
	{
		cout << A[i] << " ";
	}*/
	//cout << "\nHeapSort:   \n";
	//Heap_Sort(A);
	Build_Max_Heap(A);
	cout << "Max_Heap\n";
	for (size_t i = 1; i <= N; i++)
	{
		cout << A[i] << " ";
	}
	cout << "\n";
	int max = Heap_Max(A);
	cout << "max : = " << max << endl;
	int extract_max = Heap_Extract_Max(A);
	cout << "Extract max = " << extract_max << endl;
	for (size_t i = 1; i <= N; i++)
	{
		cout << A[i] << " ";
	}
	cout << "\n";
	Heap_Increase_Key(A, 5, 6);
	cout << "Increase key\n";
	for (size_t i = 1; i <= N; i++)
	{
		cout << A[i] << " ";
	}
	cout << "\n";
	Max_Heap_Insert(A, 40);
	cout << "Max_Heap_Insert: \n";
	for (size_t i = 1; i <= N; i++)
	{
		cout << A[i] << " ";
	}
	cout << "\n";
	system("pause");
    return 0;
}

