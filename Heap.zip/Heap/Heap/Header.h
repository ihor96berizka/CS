#pragma once
//#include"stdafx.h"
#include<iostream>

#define N 10
int Heap_Size = N;
void Swap(int & a, int & b)
{
	int temp = a;
	a = b;
	b = temp;
}
int Parent(int i)
{
	return i / 2;
}
int Left(int i)
{
	return 2 * i;
}

int Right(int i)
{
	return 2 * i + 1;
}

void Max_Heapify(int *A, int i)
{
	int l = Left(i);
	int r = Right(i);
	int largest = 0;
	if (l <= Heap_Size&&A[l] > A[i])largest = l;
	else
	{
		largest = i;
	}
	if (r <= Heap_Size&&A[r] > A[largest])largest = r;
	if (largest != i)
	{
		Swap(A[i], A[largest]);
		Max_Heapify(A, largest);
	}
}
void Min_Heapify(int *A, int i)
{
	int l = Left(i);
	int r = Right(i);
	int smallest = 0;
	if (l <= Heap_Size&&A[l] < A[i])smallest = l;
	else
	{
		smallest = i;
	}
	if (r <= Heap_Size&&A[r] < A[smallest])smallest = r;
	if (smallest != i)
	{
		Swap(A[i], A[smallest]);
		Min_Heapify(A, smallest);
	}
}
void Build_Max_Heap(int *A)
{
	for (int i = N / 2; i > 0; i--)
	{
		Max_Heapify(A, i);
	}
}
void Build_Min_Heap(int *A)
{
	for (int i = N / 2; i > 0; i--)
	{
		Min_Heapify(A, i);
	}
}

void Heap_Sort(int *A)
{
	Build_Max_Heap(A);
	/*std::cout << "Heap: \n";
	for (size_t i = 1; i <=N; i++)
	{
		std::cout << A[i] << " ";
	}
	std::cout << "\n";*/
	for (int i = N; i >= 2; i--)
	{
		Swap(A[1], A[i]);
		Heap_Size--;
		Max_Heapify(A, 1);
	}
}
int Heap_Max(int*A)
{
	return A[1];
}
int Heap_Extract_Max(int*A)
{
	if (Heap_Size < 1)std::cout<<"error, Empty!!!\n";
	int max = A[1];
	A[1] = A[Heap_Size];
	Heap_Size--;
	Max_Heapify(A, 1);
	return max;
}
void Heap_Increase_Key(int*A, int i, int key) 
{
	if (key < A[i]) {
		std::cout << "New key is less than A[" << i << "]!!!\n";
		return;
	}A[i] = key;
	while (i>1&&A[Parent(i)]<A[i])
	{
		Swap(A[i], A[Parent(i)]);
		i = Parent(i);
	}
}
void Max_Heap_Insert(int*A, int key) 
{
	//int lheap_size = Heap_Size;
	//lheap_size++;
	A[Heap_Size] = -1000;
	Heap_Increase_Key(A, Heap_Size, key);
}