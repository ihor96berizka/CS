#include"stdafx.h"

#include<random>
#include<iostream>

#define N 9
using namespace std;
template<typename T>
void Swap(T &a, T &b)
{
	T c = a;
	a = b;
	b = c;
}
template<typename T>
void merge(T arr[], int l, int m, int r)
{
	int i, j, k;
	int n1 = m - l + 1;
	int n2 = r - m;

	int *L = new int[n1 + 1];
	int *R = new int[n2 + 1];

	for (i = 0; i < n1; i++)
		L[i] = arr[l + i];
	for (j = 0; j < n2; j++)
		R[j] = arr[m + 1 + j];

	L[n1] = 1000;
	R[n2] = 1000;

	i = 0;
	j = 0;

	for (k = l; k < r + 1; k++)
	{
		if (L[i] <= R[j])
		{
			arr[k] = L[i];
			i++;
		}
		else
		{
			arr[k] = R[j];
			j++;
		}
	}
	delete[]R;
	delete[]L;
}

template<typename T>
void mergeSort(T arr[], int l, int r)
{
	if (l < r)
	{
		int m = l + (r - l) / 2;
		mergeSort(arr, l, m);
		mergeSort(arr, m + 1, r);
		merge(arr, l, m, r);
	}
}
template<typename T>
int Partition(T*A, int p, int r)
{
	T x = A[r];
	int i = p - 1;
	for (int j = p; j < r; j++)
	{
		if (A[j] <= x)
		{
			i++;
			Swap(A[i], A[j]);
		}
	}
	Swap(A[i + 1], A[r]);
	return i + 1;
}
template<typename T>
void Quick(T*A, int p, int r)
{
	if (p < r)
	{
		int	q = Partition(A, p, r);
		Quick(A, p, q - 1);
		Quick(A, q + 1, r);
	}
}
template<typename T>
int Randomized_Partition(T*A, int p, int r)
{
	int  i = p + std::rand() % r;
	Swap(A[r], A[i]);
	return Partition(A, p, r);
}
template<typename T>
int Randomized_Select(T*A, int p, int r, int i) 
{
	if (p == r) 
	{
		return A[p];
	}
	int q = Randomized_Partition(A, p, r);
	int k = q - p + 1;
	if (i == k) return A[q];
	else
		if (i < k) return Randomized_Select(A, p, q - 1, i);
		else return Randomized_Select(A, q + 1, r, i - k);
}
template<typename T>
void Randomized_Quick(T*A, int p, int r)
{
	if (p < r)
	{
		int q = Randomized_Partition(A, p, r);
		Randomized_Quick(A, p, q - 1);
		Randomized_Quick(A, q + 1, r);
	}
}
template<typename T>
void Counting_Sort(T A[], T B[], int k)
{
	int *c = new int[k+1];
	int i;
	for (i = 0; i <= k; i++)
		c[i] = 0;

	for (i = 1; i < N; ++i)
		c[A[i]] += 1;

	for (i = 1; i <= k; ++i)
		c[i] += c[i - 1];

	for (int j = N - 1; j > 0; j--)
	{
		B[c[A[j]]] = A[j];
		c[A[j]] = c[A[j]] - 1;
	}
}
template<typename T>
void Counting_Sort2(T A[])
{
	int k = 9;
	int *c = new int[k + 1];
	int i;
	T* B = new T[N];
	for (i = 0; i <= k; i++)
		c[i] = 0;

	for (i = 1; i < N; ++i)
		c[A[i]] += 1;

	for (i = 1; i <= k; ++i)
		c[i] += c[i - 1];

	for (int j = N - 1; j > 0; j--)
	{
		B[c[A[j]]] = A[j];
		c[A[j]] = c[A[j]] - 1;
	}
	for (size_t i = 0; i < N; i++)
	{
		A[i] = B[i];
	}
	delete[]B;
}