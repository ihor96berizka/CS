// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include"Header.h"
#include<iostream>
#define N 9
using namespace  std;

int _tmain(int argc, _TCHAR* argv[])
{
	int* A = new int[N];
	A[0] = 1;
	A[1] = 2;
	A[2] = 5;
	A[3] = 4;
	A[4] = 6;
	A[5] = 2;
	A[6] = 3;
	A[7] = 7;
	A[8] = 1;
	cout << "Data :\n";
	int k;
	for (int i = 0; i < N; i++) cout << A[i] << " ";
	cout << endl;

	Quick(A, 0, N-1);
	for (int i = 0; i < N; i++) cout << A[i] << " ";
	cout << endl;
	delete[]A;
	system("pause");
	return 0;
}

