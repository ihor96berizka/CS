#include "game.h"
#include<random>
#include<string>

using namespace std;

Game::Game()
{

}
void Game::Play(std::string user)
{
    string me = "";
 double   rando = (double) rand()/RAND_MAX;
    if(rando < 0.333) me = "Rock";
    if(rando >= 0.333 && rando <0.667 ) me ="Paper";
    if(rando>=0.667 && rando < 1) me = "Scissors";
    string res ="";
    cout<<"rand = "<<rando<<endl;
    if(me == user) res = "draw game \n";
  if(user == "Rock")
  {
      if (me == "Paper") res = "You loose";
      if( me == "Scissors") res = "You win";
  }
  if(user == "Paper")
  {
      if (me == "Rock") res = "You win";
      if( me == "Scissors") res = "You loose";
  }
  if(user == "Scissors")
  {
      if (me == "Rock") res = "You loose";
      if( me == "Paper") res = "You win";
  }
  cout<<"Comp :"<<me<<endl;
  cout<<res<<endl;
}
