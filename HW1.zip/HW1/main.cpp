#include <QCoreApplication>
#include<iostream>
#include"game.h"

using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
   Game *obj = new Game();
for(int i =0; i<5;i++){
   cout<<"Enter Rock, Scissors or Paper:   ";
  string user;
 cin>>user;
obj->Play(user);}
    return a.exec();
}
