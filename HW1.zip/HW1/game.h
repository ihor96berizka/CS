#ifndef GAME_H
#define GAME_H
#include<iostream>
#include<string>

 class Game
{
public:
    Game();
  static double rando;
 public: void Play(std::string);
};
#endif // GAME_H
