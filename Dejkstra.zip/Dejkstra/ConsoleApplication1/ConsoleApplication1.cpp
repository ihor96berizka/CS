// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

//#include "stdafx.h"
#include<iostream>
#include<string>
#include<climits>



using namespace std;
	
class Dejkstra
{
public:
	Dejkstra();
	~Dejkstra();
	void D(int);
private:
	string p = "";
	int n = 6;//number of vertices
	int **w;//adjacency matrix
	bool *label; //array with labels
	int *P;//array of length of path
};

Dejkstra::Dejkstra()
{
	w = new int*[n];//adjacency matrix
	for (int i = 0; i < n; i++)
		*(w + i) = new int[n];
	label = new bool[n]; //array with labels
	P = new int[n];//array of length of path
}

Dejkstra::~Dejkstra()
{
	for (int j = 0; j < n; j++) delete *(w + j);
	delete w;
	delete P;
	delete label;
}

int main()
{
	//_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	int start;
	cout << "Enter start vertex V_0 = ";
	cin >> start;
	Dejkstra obj;
	obj.D(start);
	//D(start);
	
	
	system("pause");
	
	return 0;

}
void Dejkstra::D(int start)
{

	int inf = INT_MAX;

	w[0][0] = 0;    w[0][1] = 120;   w[0][2] = 150;   w[0][3] = inf;  w[0][4] = inf;  w[0][5] = 500;
	w[1][0] = 120;  w[1][1] = 0;     w[1][2] = inf;   w[1][3] = 75;   w[1][4] = inf;  w[1][5] = 350;
	w[2][0] = 150;  w[2][1] = inf;   w[2][2] = 0;     w[2][3] = inf;  w[2][4] = 250;  w[2][5] = inf;
	w[3][0] = inf;  w[3][1] = 75;    w[3][2] = inf;   w[3][3] = 0;    w[3][4] = 150;  w[3][5] = inf;
	w[4][0] = inf;  w[4][1] = inf;   w[4][2] = 250;   w[4][3] = 150;  w[4][4] = 0;    w[4][5] = inf;
	w[5][0] = 500;  w[5][1] = 350;   w[5][2] = inf;   w[5][3] = inf;  w[5][4] = inf;  w[5][5] = 0;

	string *ver = new string[n];
	int i, j;
	for (i = 0; i < n; i++)
	{
		P[i] = *(*(w + start) + i);
		label[i] = false;
	}
	P[start] = 0;
	int index = 0, u = 0;
	for (i = 0; i < n; i++)
	{
		int min = INT_MAX;
		for (j = 0; j < n; j++)
		{
			if (!label[j] && P[j] < min)
			{
				min = P[j];
				index = j;
			}
		}
		u = index;
		label[u] = true;
		p += std::to_string(u) + " ";
		for (j = 0; j < n; j++)
		{
			if (!label[j] && *(*(w + u) + j) != INT_MAX && P[u] != INT_MAX && (P[u] + *(*(w + u) + j) < P[j]))
			{
				P[j] = P[u] + *(*(w + u) + j);
			}
		}
		ver[i] = p;
	}
	cout << "Path from start vertex to other\t\n";
	for (int k = 0; k < n; k++)
	{
		if (P[k] != INT_MAX)
			cout << start << " -> " << k << " = " << P[k] << " vertices : = " << ver[k] << endl;
		else
			cout << start << " -> " << k << " = " << "path doesn`t exist" << endl;
	}
	delete [] ver;
}
