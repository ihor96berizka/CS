﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declare variables
            int intUserGuess;
            string strPlayAgain;

            GuessMyNumberClass game = new GuessMyNumberClass();

            //start of game loop

            do
            {
                while (!game.GuessedIt)
                {
                    Console.WriteLine("Lets play a game. \n Pick a Number between 1 and 100: ");
                    intUserGuess = Convert.ToInt32(Console.ReadLine());
                    game.Evaluate(intUserGuess);
                }
                if (game.Guesses == 1)
                {
                    Console.WriteLine("Hole In One! Get Out Of My CPU Circuits! It took you { 0} tries", game.Guesses);
                }
                else if (game.Guesses > 1 && game.Guesses < 6)
                {
                    Console.WriteLine("Very good. We should play chess...I'll win, but at least it will be a challenge.It took you { 0} tries", game.Guesses);
                }
                else if (game.Guesses > 7 && game.Guesses < 11)
                {
                    Console.WriteLine("Average score. It took you {0} Tries", game.Guesses);
                }
                else if (game.Guesses > 10)
                {
                    Console.WriteLine("You Can Do Better. It took you {0} tries.", game.Guesses);
                }
                //Prompt asks the user if they wish to play again
                Console.WriteLine("Press Y to play again, or press  N enter to quit");
                strPlayAgain = Console.ReadLine().ToUpper();
            } while (strPlayAgain == "Y"); //End do loop
        }

    }
}
