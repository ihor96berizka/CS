﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class GuessMyNumberClass
    {
        Int32 intUserGuess, intGuessCount = 0;
        Int32 intCpuNumb;
        Boolean flag;
        static Random intCpuRand = new Random();
        public GuessMyNumberClass()
        {
            intCpuNumb = intCpuRand.Next(1, 101);
        }
        public Int32 Guesses { get { return intUserGuess; } }
        public Boolean GuessedIt { get { return flag; } }
        public void Evaluate(Int32 guess)
        {
            // Console.WriteLine("Lets play a game. \n Pick a Number between 1 and 100: ");
            intUserGuess = guess;//Convert.ToInt32(Console.ReadLine());
            ++intGuessCount;
            if (intCpuNumb == intUserGuess) flag = true; 
            if (intUserGuess < intCpuNumb)
            {
                Console.WriteLine("Too Low, Try Again!");
            }
            else if (intUserGuess > intCpuNumb)
            {
                Console.WriteLine("Too High, Try Again!");
            }
        }
    }
}

