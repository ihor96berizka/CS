﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Oscillator_C_sharp
{
    public partial class Form1 : Form
    {
        static List<double> xVec = new List<double>();
        static List<double> vVec = new List<double>();
        static List<double> timeVec = new List<double>();
        public Form1()
        {
            InitializeComponent();
            for (int i = 0; i < 3; i++)
            {
                chart1.Series[i].BorderWidth = 3;
            }
        }
        private   void button1_Click(object sender, EventArgs e)
        {
            double x = 2;
            double k = 10;
            double m = 800;
            double v = 0;
            double time = 0;
            double w = k / m;
            double energyP = 0;
            double energyK = 0;
            double energy = 0;

            double dt = 0.05;

            if (radioButton1.Checked == true)
            {
                foreach (var item in chart1.Series)
                {
                    item.Points.Clear();
                }

                xVec.Clear();
                vVec.Clear();
                timeVec.Clear();

                while (time < 100)
                {
                    x += dt * v;
                    v += -w * dt * x;
                    energyP = x * x * k / 2;
                    energyK = m * v * v / 2;
                    energy = energyK + energyP;
                    time += dt;

                    chart1.Series[0].Points.AddXY(time, energyP);
                    chart1.Series[1].Points.AddXY(time, energyK);
                    chart1.Series[2].Points.AddXY(time, energy);

                    xVec.Add(x);
                    vVec.Add(v);
                    timeVec.Add(time);
                }
            }

            else
            if (radioButton2.Checked == true)
            {
                foreach (var item in chart1.Series)
                {
                    item.Points.Clear();
                }

                xVec.Clear();
                vVec.Clear();
                timeVec.Clear();

                double r = Convert.ToDouble(textBox1.Text);
                while (time < 200)
                {
                    v += (-2 * r * v - w  * x);
                    x += v;
                    energyP = x * x * k / 2;
                    energyK = m * v * v / 2;
                    energy = energyK + energyP;
                    time++;

                    chart1.Series[0].Points.AddXY(time, energyP);
                    chart1.Series[1].Points.AddXY(time, energyK);
                    chart1.Series[2].Points.AddXY(time, energy);

                    xVec.Add(x);
                    vVec.Add(v);
                    timeVec.Add(time);
                }

            }
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            await Task.Run(() =>
            {
                List<List<double>> data = new List<List<double>>();
                data.Add(xVec);
                data.Add(vVec);
                Form2 portret = new Form2(data);
                portret.ShowDialog();
                xVec.Clear();
                vVec.Clear();

            });
        }

        private async void button3_Click(object sender, EventArgs e)
        {
            await Task.Run(()=> 
            {
                List<List<double>> data = new List<List<double>>();
                data.Add(xVec);
                data.Add(timeVec);
                Form3 x_t = new Form3(data);
                x_t.ShowDialog();
            });
        }
    }
}
