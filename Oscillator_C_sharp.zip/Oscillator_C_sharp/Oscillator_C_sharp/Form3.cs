﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Oscillator_C_sharp
{
    public partial class Form3 : Form
    {
        List<double> x;
        List<double> t;
        public Form3(List<List<double>> data)
        {
            InitializeComponent();
            x = data[0];
            t = data[1];
            chart1.Series[0].BorderWidth = 3;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < x.Count; i++)
            {
                chart1.Series[0].Points.AddXY(t[i], x[i]);
            }
        }
    }
}
