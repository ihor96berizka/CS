﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Oscillator_C_sharp
{
    public partial class Form2 : Form
    {
        List<double> x;
        List<double> v;
        public Form2(List<List<double>> data)
        {
            InitializeComponent();
            x = data[0];
            v = data[1];
            chart1.Series[0].BorderWidth = 3;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < x.Count; i++)
            {
                chart1.Series[0].Points.AddXY(x[i], v[i]);
            }
        }
    }
}
